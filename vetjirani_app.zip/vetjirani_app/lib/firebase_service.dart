import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_functions/cloud_functions.dart';

class FirebaseService {
  static final FirebaseService _instance = FirebaseService._internal();
  factory FirebaseService() => _instance;
  FirebaseService._internal();

  final FirebaseFunctions functions = FirebaseFunctions.instance;

  // Add the missing verifyVetMedicalId method
  Future<bool> verifyVetMedicalId(String medicalId) async {
    try {
      final HttpsCallable callable = functions.httpsCallable('verifyVetMedicalId');
      final response = await callable.call(<String, dynamic>{
        'medicalId': medicalId,
      });
      return response.data['isValid'] as bool;
    } catch (e) {
      print('Error verifying vet medical ID: $e');
      return false;
    }
  }
}
